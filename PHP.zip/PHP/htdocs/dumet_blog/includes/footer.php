<footer class="text-center">
	<small>Copyright &copy; 2015. All Rights Reserved</small>
	<small>Powered by <a href="#">www.dumetschool.com</a></small>
</footer>