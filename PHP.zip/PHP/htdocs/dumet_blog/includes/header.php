<header>
	<h1 class="text-center"><a href="index.php"><span class="glyphicon glyphicon-dashboard" aria-hidden="true"></span> DUMET Blog</a></h1>
</header>