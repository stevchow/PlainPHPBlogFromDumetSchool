<aside class="col-md-4">
    <div class="panel panel-default">
    	<div class="panel-heading">
    		<h3 class="panel-title">Komentar Terbaru</h3>
    	</div>
    	<div class="panel-body latest-comments">
    		<ul>
    		    <li><a href="index.php?detail"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span> <strong>Alissa</strong>: Many desktop publishing packages and web page editors now use.</a></li>
    		    <li><a href="index.php?detail"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span> <strong>Chelsea</strong>: All the Lorem Ipsum generators on the Internet tend to repeat predefined.</a></li>
    		    <li><a href="index.php?detail"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span> <strong>Nagita</strong>: It uses a dictionary of over 200 Latin words, combined with.</a></li>
    		</ul>
    	</div>
    </div>
</aside>

