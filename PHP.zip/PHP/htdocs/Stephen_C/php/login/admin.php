<?php
session_start();
echo"<h2>Hai, " . $_SESSION["user"] . "</h2>"

?>

<a href="logout.php">Logout</a>