<?php
function pesan(){
    echo "Saya belajar function";
}

function namaMurid ($nama){
    echo "nama saya $nama" ;   
}

function penjumlahan($a, $b){
    $c = $a + $b;
    return $c;
}



?>