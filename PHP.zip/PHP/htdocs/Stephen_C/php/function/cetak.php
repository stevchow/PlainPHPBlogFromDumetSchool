<?php
include "function.php";

pesan ();
echo "<br/>";
namaMurid ("Agustinus");
echo "<br/>";

echo penjumlahan (15,34);

?>