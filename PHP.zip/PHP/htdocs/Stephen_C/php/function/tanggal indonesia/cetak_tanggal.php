<?php 
include "function.php";

date_default_timezone_set("Asia/Jakarta");
$tanggal = date("Y-m-d H:i:s");

echo tgl_indonesia ($tanggal);


?>