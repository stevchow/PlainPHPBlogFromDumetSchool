<?php
/**Array**/

$baris = array("ala","bla","cla","dla");
echo $baris[2];

echo "<br/>";

$murid = array(
        array("a",20),
        array("afd",70),
        array("jh",50)
);
echo "nama " . $murid[2][0]; 
echo "<br/>";
echo " nilai = " . $murid[2][1];
?>