<?php
echo "<h1>Saya belajar PHP</h1>";
echo "<br/>";
echo 9;

echo "<br/>";
$string = "DUMET School";
echo $string;
echo "<br/>";

$a = 10;
$b = 8;
echo $a + $b;

$text = "Nama saya Budy";



?>