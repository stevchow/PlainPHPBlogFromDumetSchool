<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>DUMET School</title>
<link href="plugins/style.css" rel="stylesheet" type="text/css"/>
<link href="assets/shortcutdils.ico" rel="shortcut icon"/>
</head>
<body>
<div class="wrapper">
    
    <header><!-- mulai header -->
        <h1>DUMET School</h1>
    </header><!-- akhir header -->