<menu><!-- mulai menu -->
    <ul>
    	<li><a href="index.php?home">Home</a></li>
        <li><a href="index.php?about">About Us</a></li>
        <li><a href="index.php?product">Product</a></li>
        <li><a href="index.php?contact">Contact Us</a></li>
    </ul>
</menu><!-- akhir menu -->