  <footer><!-- mulai footer -->
    	<p>DUMET School | &copy; 2015</p>
    </footer><!-- akhir footer -->