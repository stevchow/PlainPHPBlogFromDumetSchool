<h2>Contact Us</h2>
        <form>
        	<table>
            <tr>
        		<td><label>Nama:</label></td>
            </tr>
            <tr>
            	<td><input type="text" name="name" required="required" placeholder="Nama Lengkap"/></td>
            </tr>
            <tr>
            	<td><label>Email</label></td>
            </tr>
            <tr>
            	<td><input type="email" name="email" required="required" placeholder="Nama Lengkap"/></td>
            </tr>
            <tr>
            	<td><label>Pesan</label></td>
            </tr>
            <tr>
            	<td><textarea placeholder="Beri masukan . . ."></textarea></td>
            </tr>
            <tr>
            	<td><input type="button" name="submit_contact" value="Kirim"/></td>
            </tr>
            </table>
        </form>