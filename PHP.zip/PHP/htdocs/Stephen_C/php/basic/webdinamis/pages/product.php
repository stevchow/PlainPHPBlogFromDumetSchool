<h2>Our Product</h2>
        <div class="prod-list">
        	<a href="#">
                <img src="images/phone.jpg"/>
                <h3>Lorem Ipsum</h3>
                <p>It has survived not only five centuries,</p>
            </a>
        </div>
        <div class="prod-list">
        	<a href="#">
                <img src="images/laptop.jpg"/>
                <h3>Lorem Ipsum</h3>
                <p>It has survived not only five centuries,</p>
            </a>
        </div>
        <div class="prod-list kanan">
        	<a href="#">
                <img src="images/projector.jpg"/>
                <h3>Lorem Ipsum</h3>
                <p>It has survived not only five centuries,</p>
            </a>
        </div>