

<?php 

include "include/header.php";
include "include/menu.php";

?>
	
  
    
    <div class="content"><!-- mulai content -->
    	<?php 
        if(isset($_GET["about"])){
            include "pages/about.php";
        } elseif(isset($_GET["product"])){
            include "pages/product.php";
        } elseif(isset($_GET["contact"])){
            include "pages/contact.php";
        } else {include "pages/home.php";}  
        ?>
    </div><!-- akhir content -->

<?php include "include/footer.php"; ?>	
  
</div>
</body>
</html>
