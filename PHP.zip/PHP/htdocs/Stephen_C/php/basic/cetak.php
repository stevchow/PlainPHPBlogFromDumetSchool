<?php

include "intro.php";

echo $text;

?>