<html>
    <head>
        <title>Date php</title>
    </head>
    <body>
        <h1>Welcome Aboard</h1>
        <p>SOKasdoasdja paosdpoksdp asdasvds</p>
        <p><?php include "include.php" ?></p>
    </body>
</html>