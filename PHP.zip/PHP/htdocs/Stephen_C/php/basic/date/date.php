<?php

date_default_timezone_set("Asia/Jakarta");

$date = date ("Y-m-d H:i:s");
echo $date;

?>