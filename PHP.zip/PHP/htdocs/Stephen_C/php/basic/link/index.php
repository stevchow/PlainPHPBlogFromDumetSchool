<a href="index.php?home">Home</a>
<a href="index.php?about">About</a>
<a href="index.php?contact">Contact</a>
<br /><br />
<?php
If (isset ($_GET["about"])){
    echo "Ini halaman About";
}else if (isset ($_GET["contact"])){
    echo "Ini halaman Contact";
}else { 
    echo "ini halaman rumah";
}

?>