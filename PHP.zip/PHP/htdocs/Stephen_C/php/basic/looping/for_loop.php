<?php

for ($a=10;$a<=100;$a+=3){
    echo $a . "<br/>";
}

for ($b=100;$b>=1;$b--){
    echo $b . "<br/>";
}
?>