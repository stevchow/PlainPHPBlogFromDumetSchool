<?php
$angka = 45;
while($angka <= 50){
    echo $angka;
    $angka++;
}
?>