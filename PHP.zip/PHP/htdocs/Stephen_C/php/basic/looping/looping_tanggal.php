<select>
    <option>Tanggal</option>
    <?php for($a=1;$a<=31;$a++){ ?>
    <option><?php echo $a ?></option>
    <?php } ?>
</select>

<select>
    <?php
    $bulan = array ("Jan","Feb","Mar","Apr","May","Jun","Jul","Agt","Sep","Oct","Nov","Dec");
    ?>
    
    <option>Month</option>
    <?php for($b=0;$b<=11;$b++){ ?>
    <option><?php echo $bulan [$b] ?></option>
    <?php } ?>
    
</select>

<select>
    <option>Year</option>
    <?php for($c=2017;$c>=1945;$c--){ ?>
    <option><?php echo $c ?></option>
    <?php } ?>
</select>