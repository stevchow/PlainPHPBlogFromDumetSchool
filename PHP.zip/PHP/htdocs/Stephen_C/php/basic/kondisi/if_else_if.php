<?php 
$lampu = "mfgerah";
if ($lampu == "merah") {
    echo "berhenti";
} else if($lampu == "kuning") {
    echo "siap-siap";
} else if($lampu == "hijau") {
    echo "JALAN Oi!"; 
}else {
    echo "RUSAK HARAP MAKLUM!";
}


?>