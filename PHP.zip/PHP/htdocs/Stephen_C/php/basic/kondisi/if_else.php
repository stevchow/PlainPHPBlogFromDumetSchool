<?php
$umur = 8;
if ($umur >= 18){
  echo "Anda boleh menonton video ini.";  
}else {
    echo "Anda NGAK! boleh menonton video ini.";
}



?>