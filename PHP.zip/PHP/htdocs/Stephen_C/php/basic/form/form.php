<form action="" method="post">
    <input type="text" name="teks"/>
    <input type="submit" value="CETAK" name="hasil" />
</form>

<?php
if (isset($_POST["hasil"])){
    $teks = $_POST["teks"];
    echo $teks;
}


?>