<?php

session_start();

echo $_SESSION["instruktur"] . "<br/>";
echo $_SESSION["alamat"];


?>