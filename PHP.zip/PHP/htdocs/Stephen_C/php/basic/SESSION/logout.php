<?php

session_start();
/**HAPUS SESSIONS**/
session_unset();

session_destroy();
echo "Sessions telah dihapus";

?>