<?php
/**Session**/
session_start();
$_SESSION["instruktur"] = "Agustinus";
$_SESSION [ "alamat"] = "Jakarta";

echo "SESSION telah aktif";


 ?>