<?php
/**koneksi database**/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webmaster";
$connection = mysqli_connect($servername,$username,$password,$dbname);

/**CEK KONEKSI**/
if (!$connection) {
    die ("Connection failed : ".mysqli_connect_error());
}

?>