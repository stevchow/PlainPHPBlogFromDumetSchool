<?php
include "config.php";

/**Proses UPDATEEE data**/
if(isset($_POST["ubah"])){
    $_id = $_POST["id"];
    $nama = $_POST ["nama"];
    $alamat = $_POST ["alamat"];
    $notelp = $_POST ["notelp"];
    $paket = $_POST["paket"];
    mysqli_query($connection, "UPDATE latihancrud SET nama = '$nama', alamat = '$alamat' , no_telp = '$notelp' , paket_kursus = '$paket'  
    WHERE id = '$_id'"); header ("location:index.php");
}

/**TAMPIL data pada form**/
$id = $_GET ["update"];
$edit = mysqli_query ($connection, "SELECT * FROM latihancrud WHERE id='$id'");
if(mysqli_num_rows($edit)== 0) header ("location:index.php");
$row_edit = mysqli_fetch_array($edit);


/**QUERY**/
$query = mysqli_query($connection, "SELECT * FROM latihancrud");
 
?>

<form method="post">
    <input type="text" name="nama" placeholder="Nama" value="<?php echo $row_edit["nama"]?>"/><br /><br />
    <input type="text" name="alamat" placeholder="Alamat" value="<?php echo $row_edit["alamat"]?>"/><br /><br />
    <input type="text" name="notelp" placeholder="Nomor Telepon" value="<?php echo $row_edit["no_telp"]?>"/><br /><br />
    <input type="text" name="paket" placeholder="Paket Kursus"value="<?php echo $row_edit["paket_kursus"]?>"/><br /><br />
    <input type="submit" value="Ubah" name="ubah"/>
    <input type="reset" value="batal"/>
    <input type="hidden" name="id" value="<?php echo $row_edit["id"]?>"/>
</form>
<br /><br />


<table border=1>
<tr>
    <th>No</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Nomor Telp</th>
    <th>Paket Kursus</th>
    <th>Action</th>
</tr>


    <?php
    if (mysqli_num_rows($query) > 0) {?>
    <?php $no = 1 ?>
        <?php while($row = mysqli_fetch_array($query)){ ?>
            <tr>
                <td><?php echo $no ?></td>
                <td><?php echo $row["nama"] ?></td>
                <td><?php echo $row["alamat"] ?></td>
                <td><?php echo $row["no_telp"] ?></td>
                <td><?php echo $row["paket_kursus"]?></td>
                <td>
                    <a href="update.php?update=<?php echo $row["id"]?>">Update</a>
                    <a href="delete.php?delete=<?php echo $row["id"]?>">Delete</a>
                </td>
            </tr>
        <?php $no++; } ?>
    <?php } ?>
    
    
</table>
<?php
mysqli_close($connection);
?>