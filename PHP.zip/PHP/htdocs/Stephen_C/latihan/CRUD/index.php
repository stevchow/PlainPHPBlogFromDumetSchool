<?php
include "config.php";
/**Proses input data**/
if(isset($_POST["simpan"])){
    $nama = $_POST ["nama"];
    $alamat = $_POST ["alamat"];
    $notelp = $_POST ["notelp"];
    $paket = $_POST ["paket"];
    mysqli_query($connection, "INSERT INTO latihancrud VALUES ('','$nama','$alamat','$notelp','$paket')");
   header ("location:index.php");
}
/**QUERY**/
$query = mysqli_query($connection, "SELECT * FROM latihancrud");
 
?>

<form method="post">
    <input type="text" name="nama" placeholder="Nama"/><br /><br />
    <input type="text" name="alamat" placeholder="Alamat"/><br /><br />
    <input type="text" name="notelp" placeholder="Nomor Telepon"/><br /><br />
    <input type="text" name="paket" placeholder="Paket Kursus"/><br /><br />
    <input  type="submit" value="simpan" name="simpan"/>
    <input type="reset" value="batal"/>
</form>
<br /><br />


<table border=1>
<tr>
    <th>No</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Nomor Telp</th>
    <th>Paket Kursus</th>
    <th>Action</th>
</tr>


    <?php
    if (mysqli_num_rows($query) > 0) {?>
    <?php $no = 1 ?>
        <?php while($row = mysqli_fetch_array($query)){ ?>
            <tr>
                <td><?php echo $no ?></td>
                <td><?php echo $row["nama"] ?></td>
                <td><?php echo $row["alamat"] ?></td>
                <td><?php echo $row["no_telp"] ?></td>
                <td><?php echo $row["paket_kursus"]?></td>
                <td>
                    <a href="update.php?update=<?php echo $row["id"]?>">Update</a>
                    <a href="delete.php?delete=<?php echo $row["id"]?>">Delete</a>
                </td>
            </tr>
        <?php $no++; } ?>
    <?php } ?>
    
    
</table>
<?php
mysqli_close($connection);
?>