<?php
/**koneksi database**/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "latihan_crud";
$connection = mysqli_connect($servername,$username,$password,$dbname);

/**CEK KONEKSI**/
if (!$connection) {
    die ("Connection failed : ".mysqli_connect_error());
}

?>