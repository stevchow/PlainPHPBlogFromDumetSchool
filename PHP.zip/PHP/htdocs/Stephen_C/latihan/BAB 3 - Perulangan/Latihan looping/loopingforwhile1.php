<?php
echo "Lat 1" . "<br/>";
for ($a=1;$a<=5;$a+=1){
    echo "This number is " . $a . "<br/>";
}

echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";

echo "Lat 2" . "<br/>";
for ($a=1;$a<=10;$a+=2){
    echo "This number is " . $a . "<br/>";
}

echo "<br/>";
echo "Lat 3" . "<br/>";
?>

<html>
    <style>
    table {
        width:170px;
    }
    
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    td {
	text-align : right;
    }
    
    th {
        font-weight : bold;
        text-align : left;
        background-color: grey;
        color: black;
    }
    </style>
    
    
    <table>
      <tr>
        <th>Quantity</th>
        <th>Price</th>
      </tr>
      <tr>
        <td><?php
            $angka1 = 10;
            while($angka1 <= 100){
                echo $angka1 . "<br/>";
                $angka1+=10;}
        ?></td>
        <td><?php
            $angka2 = 300;
            while($angka2 <= 3000){
                echo $angka2 . "<br/>";
                $angka2+=300;}
        ?></td>
      </tr>
    </table> 
</html>

