<html>
    <style>
    table {
        width:220px;
        text-align: center;
    }
    
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
     
    th {
        background-color: #F1F1F1;
    }
    </style>
    
    
    <table>
      <tr>
        <th>Tahun</th>
        <th>Terjual</th>
        <th>Profit</th>
      </tr>
      <tr>
        <td><?php
            $angka1 = 2000;
            while($angka1 <= 2010){
                echo $angka1 . "<br/>";
                $angka1+=1;}
        ?></td>
        <td><?php
            $angka2 = 1500;
            while($angka2 <= 16500){
                echo $angka2 . "<br/>";
                $angka2+=1500;}
        ?></td>
        
        <td><?php
            $angka3 = 100;
            while($angka3 <= 1100){
                echo $angka3 ."juta" . "<br/>";
                $angka3+=100;}
        ?></td>
        
      </tr>
    </table> 
</html>