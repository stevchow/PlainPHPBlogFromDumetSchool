<?php
date_default_timezone_set("Asia/Jakarta");
$tanggal = date ("Y-m-d H:i:s");
$tempat = "DUMET School";
$paket = "webmaster";

echo "Belajar PHP itu Mudah. Saya mulai belajar " . $paket . " di " . $tempat . " pada tanggal " . $tanggal . "."; 



?>