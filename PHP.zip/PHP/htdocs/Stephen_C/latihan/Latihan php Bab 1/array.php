<?php

$jamtgn = array ("Omega", "Rolex", "Casio", "Hublot");
 
echo "Saya suka jam tangan  $jamtgn[1] ,  $jamtgn[0],  $jamtgn[3]  dan $jamtgn[2]. ";

?>