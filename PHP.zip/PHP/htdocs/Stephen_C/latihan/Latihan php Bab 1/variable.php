<?php

$nama = "Rully Febrian";
$tempat = "DUMET School";

echo "Hello nama saya " . $nama . "." . "Saya sedang belajar PHP di " . $tempat . ".";


?>