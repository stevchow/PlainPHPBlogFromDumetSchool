
      <div class="sidebar">
      <h3>Search</h3>
        <form method="post" action="#" id="search_form">
          <p>
            <input class="search" type="text" name="search_field" value="Enter keywords....." />
            <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="style/search.png" alt="Search" title="Search" />
          </p>
        </form>
        <!-- insert your sidebar items here -->
        <h3>Latest News</h3>
        <h4>Website, Digital Marketing, & Mobile App Development.</h4>
        <h5>August 1st, 2013</h5>
        <p>DUMET Development adalah sebuah Digital Agency yang bergerak sebagai Konsultan IT di Jakarta.<br /><a href="#">Read more</a></p>
        <p></p>
        <h4>Website, Digital Marketing, & Mobile App Development.</h4>
        <h5>August 1st, 2013</h5>
        <p>DUMET Development adalah sebuah Digital Agency yang bergerak sebagai Konsultan IT di Jakarta.<br /><a href="#">Read more</a></p>
        <h3>Paket Kursus</h3>
        <ul>
          <li><a href="#">Web Master 2.0</a></li>
          <li><a href="#">Digital Marketing</a></li>
          <li><a href="#">Graphic Design</a></li>
          <li><a href="#">Web Design</a></li>
          <li><a href="#">Flash Animation</a></li>
        </ul>
      </div>
