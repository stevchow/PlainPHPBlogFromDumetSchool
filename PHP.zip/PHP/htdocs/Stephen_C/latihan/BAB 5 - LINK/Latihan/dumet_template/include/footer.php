<div id="footer">
      Copyright &copy; 2013 -2015 PT. Duta Media Teknologi | <a href="http://www.dumetschool.com" target="_blank">dumetschool.com</a>
</div>