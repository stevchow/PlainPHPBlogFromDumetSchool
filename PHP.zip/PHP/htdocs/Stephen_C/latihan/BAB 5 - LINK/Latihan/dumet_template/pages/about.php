<h1>Siapa Kami</h1>
        <p>DUMET Development adalah sebuah Digital Agency yang bergerak sebagai Konsultan IT di Jakarta. Fokus Kami adalah membuat dan menciptakan produk terbaik pada bidang teknologi informasi. Kami lahir atas nama perusahaan pada tahun 2013. Pengalaman tim Kami lebih dari 11 tahun dibidang IT.</p>
        <h1>Tujuan Kami</h1>
        <p>Kami membangun dan membuat menggunakan teknologi terdepan, sehingga dapat menghasilkan performa terbaik pada produk Anda. Developer Kami dapat memenuhi kebutuhan Anda.

Sistem Kami siap membangun dan mengembangkan setiap halaman website Anda yang memiliki relevansi yang dapat meng-konversikan dari pengunjung yang hanya mencari dan melihat saja akan menjadi pembeli.

Mempermudah pengguna adalah tujuan Kami. Dengan aplikasi berbasis Mobile maka dapat menjangkau secara luas calon pembeli tetap produk-produk Anda. </p>
      