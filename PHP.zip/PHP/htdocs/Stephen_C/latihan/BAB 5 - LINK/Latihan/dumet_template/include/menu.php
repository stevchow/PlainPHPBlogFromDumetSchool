<div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Dumet<span class="logo_colour">School</span></a></h1>
          <h2>web and mobile training</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="indexdumet.php?home">Home</a></li>
          <li><a href="indexdumet.php?about">About</a></li>
          <li><a href="indexdumet.php?profile">Profile</a></li>
          <li><a href="indexdumet.php?blogs">Blogs</a></li>
          <li><a href="indexdumet.php?contactus">Contact Us</a></li>
        </ul>
      </div>
    </div>