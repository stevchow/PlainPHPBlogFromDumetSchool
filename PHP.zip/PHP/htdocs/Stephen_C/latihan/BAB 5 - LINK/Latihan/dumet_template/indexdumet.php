<?php 

include "include/header.php";


?>
	
  
    
    <div id="main"><!-- mulai content -->
        <?php include "include/menu.php"; ?>
  
        <div id="site_content">
            <?php include "include/side.php"; ?>
            <div id="content">
                	<?php 
                    if(isset($_GET["about"])){
                        include "pages/about.php";
                    } elseif(isset($_GET["blogs"])){
                        include "pages/blogs.php";
                    } elseif(isset($_GET["profile"])){
                        include "pages/profile.php";
                    } elseif(isset($_GET["contactus"])){
                        include "pages/contactus.php";
                    } else {include "pages/home.php";}  
                    ?>
            </div>
        </div>
        
        <?php include "include/footer.php"; ?>
        
    </div><!-- akhir content -->

	
  
</div>
</body>
</html>