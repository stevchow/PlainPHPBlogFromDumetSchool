<!DOCTYPE HTML>
<html>

<head>
  <title>KURSUS WEBSITE, WEB DESIGN, SEO TERBAIK 205</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
  <link href="favicon.ico" rel="icon">
</head>