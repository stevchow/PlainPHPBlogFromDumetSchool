<html>
<body>
    <form action="" method="post">
    <p>Nama</p> <input type="text" name="id" placeholder="ID"/>
  
    <input type="submit" value="CETAK" name="hasil" />
    <input type="reset" value="CANCEL" name="" />
    </form>
</body>

</html>

<?php
if (isset($_POST["hasil"])){
    $id = $_POST["id"];
    if ($id == "R001" ){
          $nama =  "ABCD";  
        }else if($id == "R002" ){
         $nama = "ffff";   
        }else if($id == "R003" ){
         $nama = "gggg"; 
        }
        else {echo "tidak terdaftar";};
    echo "ID : " . $id . "<br/>" . "Nama : " . $nama;
}




?>