<html>
<body>
    <form action="" method="post">
    <p>Nama</p> <input type="text" name="teks" placeholder="Nama Lengkap"/>
    <p>Jabatan</p> 
        <select name="jabatan">
            <?php $jabatan = array ("Manager", "Supervisor" , "Cashier" , "Sales Executive");?>
            
            <option value="" disabled selected> - Jabatan - </option>
            <?php for($b=0;$b<=3;$b++){ ?>
            <option><?php echo $jabatan [$b] ?></option>
            <?php } ?>
        </select>
    <input type="submit" value="CETAK" name="hasil" />
    </form>
</body>

</html>

<?php
if (isset($_POST["hasil"])){
    $teks = $_POST["teks"]; 
    $jabatan = $_POST["jabatan"];
    
    echo "Nama : " . $teks . "<br/>";
    echo "Jabatan : " . $jabatan . "<br/>";
}
?>