<?php
$umur = 8;
if ($umur >= 1 && $umur <=10 ){
  echo "Anak-anak";  
}else if($umur >= 11 && $umur <=20 ){
  echo "Remaja";  
}else if($umur >= 21 && $umur <=50 ){
  echo "Dewasa";  
}else {echo "Lansia";}



?>