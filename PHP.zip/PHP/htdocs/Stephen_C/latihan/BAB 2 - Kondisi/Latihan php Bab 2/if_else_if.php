<?php 


$menu = "Nasi Goreng";
if ($menu == "Nasi Goreng") {
    $harga= "15.000";
} else if($menu == "Pecel Lele") {
    $harga= "13.000";
} else if($menu == "Gado-gado") {
    $harga= "12.000"; 
} else if($menu == "Pecel Ayam") {
    $harga= "17.000"; 
} else if($menu == "Ayam Bakar") {
    $harga= "18.000"; 
} else if($menu == "Sate Padang") {
    $harga= "15.000"; 
} else {
    $harga= "Tidak Jual";
}

echo "Jika memilih ". $menu . " Harganya Rp. ". $harga  ;

echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";

$nilai = 85;
if ($nilai>= 90 && $nilai <=100 ){
  $peringkat= "A";  
}else if($nilai >= 80 && $nilai <=89 ){
  $peringkat= "B";  
}else if($nilai >= 70 && $nilai <=79 ){
  $peringkat= "C";  
}else if($nilai >= 60 && $nilai <=69 ){
  $peringkat= "D";  
}else if($nilai <=59 ){
  $peringkat= "E";  
}
else {echo "Terlalu pintar";}

echo "Jika nilai ". $nilai . " Peringkat ". $peringkat  ;

echo "<br/>";
echo "<br/>";
echo "<br/>";
echo "<br/>";


$nilaitugas = 60;
$nilaiujian = 70;

$nilai = ($nilaitugas + $nilaiujian) / 2;
if ($nilai>= 60 && $nilai <=100 ){
  $status= "LULUS";  
}else if($nilai <=59 ){
  $status= "TIDAK LULUS";  
}
else {echo "Terlalu pintar";}

echo "nilai akhir = ". $nilai . ", Jadi Anda Dinyatakan ". $status  ;



?>