<h4>LOGIN</h4>
<form method="post">
    <table>
        <tr>
            <td><p>Username</p></td>
            <td>
            <input type="text" name="username" placeholder=""/>
            </td>
        </tr>
    
        <tr>
            <td><p>Password</p></td>
            <td><input type="password" name="password" placeholder=""/></td>
        </tr>
        
        <?php
            if(isset($_GET["error"])){
                echo"<p style='color:red'>Maaf Username dan Password Anda tidak terdaftar</p>";
            }
        ?>
        
        <tr>
            <td><input type="submit" name="login" value="login"/></td>
        </tr>
        
    </table>

</form>

<?php
session_start();
$user = "lalala";
$pwd = "123";

if (isset($_POST["login"])){
    if($_POST["username"]==$user &&
    $_POST ["password"]== $pwd ) {
        $_SESSION["user"] = $_POST["username"];
        $_SESSION["pwd"] = $_POST["password"];
    header ("location:admin.php");
    
    }else{
        header ("location:index.php?error");
    }
}



?>