<?php

session_start();
/**HAPUS SESSIONS**/
session_unset();

session_destroy();
header("location:index.php");


?>