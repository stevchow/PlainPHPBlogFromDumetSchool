
<div style="overflow:hidden;">
<?php
session_start();
echo "<p style='float:left;'>Dumet Application</p>";
echo"<p style='float:right;'>Selamat Datang, " . $_SESSION["user"] . " | " .  "<a href='logout.php'> Logout</a></p>";
?> 

</div>


<?php
echo "<br/>" . "<h2 style='text-align:center'>Ini Halaman Administrator</h2>";

?>
