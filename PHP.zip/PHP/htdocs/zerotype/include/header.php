<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Zerotype Website Template</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<div id="header">
		<div>
			<div class="logo">
				<a href="index.php">Zero Type</a>
			</div>
			<ul id="navigation">
				<li class="active">
					<a href="index.php?home">Home</a>
				</li>
				<li>
					<a href="index.php?features">Features</a>
				</li>
				<li>
					<a href="index.php?news">News</a>
				</li>
				<li>
					<a href="index.php?about">About</a>
				</li>
				<li>
					<a href="index.php?contact">Contact</a>
				</li>
			</ul>
		</div>
	</div>